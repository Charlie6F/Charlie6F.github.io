import flet as ft
import json
import logging
import re
from urllib.parse import quote, urlparse
import sys
import requests
from time import sleep
from functools import partial
import asyncio
from nkiri_movie_updater import MovieUpdateScraper
import tmdbsimple as tmdb
import os 
from datetime import datetime 
from dotenv import load_dotenv, dotenv_values 
# loading variables from .env file
load_dotenv() 


# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Configuration
CONFIG = {
    "proxy_port": 7259,
    "http(s)": "https",
    #"dl_port": 8011,
    #"yt_port": 5000,
    "host": "nexu.charles06f.workers.dev", #"bore.pub:8133",# "localhost:8080",
    "default_image_height": 320,
    "default_image_width": 320,
    "grid_runs_count": 2,
    "grid_aspect_ratio": 0.535,
    "grid_spacing": 5,
    "grid_padding": 10,
    "batch_size": 10,
    "column_width": 400,  #Added for responsiveness
}

TIPS = [
    "Double-tap any movie card to download",
    "Click the info icon to view movie details",
    "Use the search bar to find specific movies",
    "Hover over cards to see animation effects",
    "Toggle between light and dark themes using the sun/moon icon",
    "Click the search icon to show/hide the search bar",
    "Recent searches appear in search suggestions",
]


class MovieDataProcessor:
    def __init__(self):
        self.logger = logger
        self.api_key = os.getenv("TMDB_API_KEY")
        tmdb.API_KEY = self.api_key
        self.delay = 0.25  # Add delay between API calls to respect rate limits
        
    def validate_api_key(self) -> bool:
        """Validate TMDB API key"""
        if not self.api_key:
            self.logger.error("TMDB API key not found in environment variables")
            return False
        try:
            search = tmdb.Search()
            search.movie(query="test")
            self.logger.info("TMDB API key validated successfully")
            return True
        except Exception as e:
            self.logger.error(f"Invalid TMDB API key: {str(e)}")
            return False
            
    def process_batch(self, movies: list, start_idx: int = 0, batch_size: int = 10) -> tuple[list, int]:
        """Process a batch of movies to fetch their information
        
        Args:
            movies: List of movies to process
            start_idx: Starting index in the movies list
            batch_size: Number of movies to process in this batch
            
        Returns:
            tuple: (processed movies list, next start index)
        """
        end_idx = min(start_idx + batch_size, len(movies))
        
        for idx in range(start_idx, end_idx):
            try:
                movie = movies[idx]
                if not all(key in movie for key in ["Overview", "Genres", "Rating (Average)"]):
                    title = self.clean_title(movie.get('title', ''))
                    info = self.get_movie_info(title)
                    
                    if info:
                        movie.update(info)
                        self.logger.info(f"Updated info for movie: {title}")
                    else:
                        self.logger.warning(f"No info found for movie: {title}")
                        
                sleep(self.delay)  # Respect API rate limits
                
            except Exception as e:
                self.logger.error(f"Error processing movie at index {idx}: {str(e)}")
                continue
                
        return movies, end_idx

    def clean_title(self, title: str) -> str:
        """Clean movie title by removing year, download text and other unnecessary parts."""
        try:
            title = re.sub(r'\s*\(\d{4}\).*$', '', title)
            title = re.sub(r'\s*\(.*?).*$', '', title)           
            title = re.sub(r'Download\s+', '', title, flags=re.IGNORECASE)
            title = re.sub(r'Hollywood\s+Movie', '', title, flags=re.IGNORECASE)
            title = re.sub(r'[^\w\s-]', '', title)
            cleaned_title = title.strip()
            return cleaned_title
        except Exception as e:
            self.logger.error(f"Error cleaning title '{title}': {str(e)}")
            return title

    def get_movie_info(self, title: str):
        """Get movie information from TMDB API."""
        search = tmdb.Search()
        
        params = {"query": title}
        
        try:
            response = search.movie(**params)
            if search.total_results > 0:
                first_result = search.results[0]
                movie = tmdb.Movies(first_result['id'])
                movie_info = movie.info()
                
                info = {
                    "Overview": movie_info.get('overview', ''),
                    "Genres": ", ".join([genre['name'] for genre in movie_info.get('genres', [])]),
                    "Rating (Average)": f"{movie_info.get('vote_average', 0):.1f}"
                }
                self.logger.info(f"Successfully fetched info for '{title}'")
                return info
            else:
                self.logger.warning(f"No results found for movie '{title}'")
                
        except Exception as e:
            self.logger.error(f"Error fetching info for '{title}': {str(e)}")
        
        return None
        
    @staticmethod
    def process_movie_data(raw_data):
        title = raw_data.get("title", "Untitled").split("|")[0].strip()
        return {
            "title": title,
            "link": raw_data.get("link", ""),
            "image_url": raw_data.get("image_link", ""),
            "date": raw_data.get("date", "No date"),
            "download_link": raw_data.get("download_link", ""),
            "overview": raw_data.get("Overview", "No overview available"),
            "genres": raw_data.get("Genres", "No genres available"),
            "rating": raw_data.get("Rating (Average)", "No rating available"),
            # Add trailer URL - will be searched dynamically based on title
            "trailer_url": None,
        }


class SearchProcessor:
    def __init__(self):
        self.recent_searches = []
        self.max_recent_searches = 5
    
    def add_recent_search(self, query):
        if query and query not in self.recent_searches:
            self.recent_searches.insert(0, query)
            if len(self.recent_searches) > self.max_recent_searches:
                self.recent_searches.pop()
    
    def get_suggestions(self, query, movies):
        if not query:
            return self.recent_searches[:5]
        
        query = query.lower()
        suggestions = []
        
        # Add matching recent searches
        for recent in self.recent_searches:
            if query in recent.lower():
                suggestions.append(recent)
        
        # Add matching movie titles
        for movie in movies:
            if query in movie["title"].lower():
                suggestions.append(movie["title"])
                if len(suggestions) >= 5:
                    break
        
        return suggestions[:5]        
        
class UpdateProgress(ft.Container):
    def __init__(self):
        super().__init__()
        self.status = ft.Text("Checking for new movies...", size=14)
        self.progress = ft.ProgressRing()
        self.stop_button = ft.TextButton("Cancel", on_click=self.stop_update)
        self.running = False
        self.on_stop = None

        # Update container properties directly
        self.content = ft.Column([
            ft.Row(
                [self.progress, ft.Text("    "), self.status],
                alignment=ft.MainAxisAlignment.CENTER,
            ),
            ft.Divider(),
            self.stop_button
        ],
        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
        )
        self.padding = 20

    def update_status(self, message):
        self.status.value = message
        self.update()

    def stop_update(self, e=None):
        self.running = False
        if self.on_stop:
            self.on_stop()

    def did_mount(self):
        self.running = True

    def will_unmount(self):
        self.running = False
        
class MovieCardCreator:
    def __init__(self, proxy_port, host, page=None):
        self.proxy_port = proxy_port
        self.host = host
        self.loading_dialog = None
        self.movie_info_dialog = None
        self.page = page
        self.animation_duration=2000
        self.stop_get_direct_url = False  # Added as instance variable

    def set_page(self, page):
        """Set the page reference"""
        self.page = page

    def create_fallback_content(self):
        return ft.Container(
            content=ft.Icon(ft.icons.ERROR_OUTLINE),
            bgcolor=ft.colors.SURFACE_VARIANT,
            height=CONFIG["default_image_height"],
            width=CONFIG["default_image_width"],
            alignment=ft.alignment.center
        )

    def _show_error_dialog(self, page, message):
        error_dialog = ft.AlertDialog(
            modal=True,
            title=ft.Text("Error"),
            content=ft.Text(message),
            actions=[
                ft.TextButton("OK", on_click=lambda _: page.close(error_dialog))
            ]
        )    
        page.open(error_dialog)
        page.update()

    def _handle_download(self, e, url):
        page = e.page or self.page
        sleep(1)
        self.stop_get_direct_url = False  # Reset flag at start of download

        def _stop_get_direct_url(e):
            self.stop_get_direct_url = True  # Use instance variable
            page.close(self.loading_dialog)
            page.update()

        if not page:
            logger.error("No page reference available")
            return

        try:
            # Show loading dialog
            self.loading_dialog = ft.AlertDialog(
                modal=True,
                title=ft.Text("Processing Download"),
                content=ft.Container(
                    ft.Column(
                        [
                            ft.Row(
                                [
                                    ft.ProgressRing(),
                                    ft.Text("    Fetching download link...", size=14),
                                ],
                                alignment=ft.MainAxisAlignment.CENTER,
                            ),
                            ft.Divider(),
                            ft.TextButton(
                                "Cancel",
                                style=ft.ButtonStyle (
                                    text_style=ft.TextStyle(

                                    ),
                                ),
                                on_click=_stop_get_direct_url
                            ),
                        ],
                        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                    ),
                    height=100,
                )
            )

            page.open(self.loading_dialog)
            page.update()

            try:
                if not self.stop_get_direct_url:  # Check instance variable
                    if url:
                        try:
                            server_url = f"{CONFIG['http(s)']}://{CONFIG['host']}/api/download?" # URL of your nodejs server
                            response = requests.get(server_url, params={"url": url})
                            response.raise_for_status()  # Raise HTTPError for bad responses (4xx or 5xx)
                            try:
                              data = response.json() 
                              direct_url = data.get("url")
                              if direct_url and 'downloadwella.com' in direct_url:
                                 direct_url = self.cleanup_download_url(direct_url)
                            except json.JSONDecodeError as e:
                                 logger.error(f"Error parsing JSON response from server: {e}")
                                 direct_url = None
                                 self._show_error_dialog(
                                      page,
                                      "Server returned an invalid response."
                                )

                        except requests.exceptions.RequestException as e:
                            logger.error(f"Error calling the Node.js server: {e}")
                            if e.response is not None:
                                  logger.error(f"Server response status: {e.response.status_code}")
                                  if e.response.status_code == 400:
                                      try:
                                          error_data = e.response.json()
                                          error_message = error_data.get('message', "Invalid Request URL")
                                          self._show_error_dialog(page, f"Invalid URL: {error_message}")
                                      except json.JSONDecodeError:
                                         self._show_error_dialog(page, "Invalid URL")

                                  if e.response.status_code >= 500:
                                       self._show_error_dialog(page, "Server error occurred")
                                  else:
                                       self._show_error_dialog(page, f"Network error occurred: {e}")
                            else:
                                  self._show_error_dialog(page, f"Network error occurred: {e}")
                            direct_url = None
                    else:
                        direct_url = None

                    if self.loading_dialog:
                        page.close(self.loading_dialog)

                    if direct_url and not self.stop_get_direct_url:  # Check again after getting URL
                        page.launch_url(direct_url)
                    elif not self.stop_get_direct_url:  # Only show error if not cancelled
                        self._show_error_dialog(
                            page,
                            "Unable to fetch download link. Please try again later."
                        )

            except Exception as ex:
                logger.error(f"Error processing download: {ex}")
                if not self.stop_get_direct_url:  # Only show error if not cancelled
                    self._show_error_dialog(
                        page,
                        f"An error occurred: {str(ex)}"
                    )

        finally:
            page.update()
    
    def cleanup_download_url(self, url):
        try:
          parsed_url = urlparse(url)
          path = parsed_url.path
          match = re.search(r'/([^/]+)$', path)
          if match:
            filename = match.group(1)
            
            #Use regular expression to clean up filename
            filename = re.sub(r'\.DOWNLOADED\.FROM\.NKIRI\.COM', '', filename, flags=re.IGNORECASE)
            filename = re.sub(r'\(\w+\.COM\)', '', filename, flags=re.IGNORECASE)
            print (filename)
            
            new_url = parsed_url._replace(path=f"{'/'.join(path.split('/')[:-1])}/{filename}").geturl()
            return new_url
    
          return url
        except Exception as e:
           logger.error(f"Error cleaning up URL: {e}")
           return url
    
    def _show_movie_info_dialog(self, movie_data):
        page = self.page
        if not page:
            logger.error("No page reference available")
            return
        
        image_url = movie_data["image_url"]
        proxied_url = f"{CONFIG['http(s)']}://{self.host}/api/image?url={quote(image_url)}" if image_url else None
        
        self.movie_info_dialog = ft.AlertDialog(
                modal=True,
                content_padding=ft.padding.only(top=0,),
                content=ft.Container(
                    content=ft.Column(
                        [
                            ft.Image(
                                src=proxied_url,
                                fit=ft.ImageFit.COVER,
                                height=CONFIG["default_image_height"],
                                width=CONFIG["default_image_width"],
                                error_content=self.create_fallback_content(),
                            ),
                            ft.Text(movie_data["title"],weight=ft.FontWeight.BOLD,size=15 ),
                            ft.ListTile(
                                title=ft.Text("Genres:", weight=ft.FontWeight.BOLD),
                                subtitle=ft.Text(movie_data["genres"]),
                            ),
                            ft.ListTile(
                                title=ft.Text("Rating:", weight=ft.FontWeight.BOLD),
                                subtitle=ft.Text(f"{movie_data['rating']} {chr(0x1F31F) *int(float(movie_data['rating']))}"),
                            ),
                            ft.ListTile(
                                title=ft.Text("Overview:", weight=ft.FontWeight.BOLD),
                                subtitle=ft.Text(movie_data["overview"], max_lines=15, overflow=ft.TextOverflow.ELLIPSIS),
                            ),
                            ft.Row(
                                [
                                    ft.ElevatedButton(
                                        "Watch Trailer",
                                        icon=ft.icons.PLAY_CIRCLE,
                                        on_click=lambda e: self.play_trailer(e, movie_data)
                                    )
                                ],
                                alignment=ft.MainAxisAlignment.CENTER,
                            )
                        ],
                        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                        scroll=ft.ScrollMode.ADAPTIVE,
                    ),
                    height=CONFIG["default_image_height"]*1.5,
                    width=CONFIG["default_image_width"] * 1.2,
                ),
                elevation=24,
                shadow_color=ft.Colors.BLUE_900,
                actions=[
                    ft.TextButton("Close", on_click=lambda _: page.close(self.movie_info_dialog))
                ]
        )
    
        page.open(self.movie_info_dialog)
        page.update()

        
    def search_youtube_trailer(self, movie_title):
        try:
            search_query = f"{movie_title} official trailer"
            server_url = f"{CONFIG['http(s)']}://{CONFIG['host']}/api/youtube?"  # You'll need to implement this endpoint
            response = requests.get(server_url, params={"q": search_query})
            response.raise_for_status()
            data = response.json()
            return data.get("videoId")
        except Exception as e:
            logger.error(f"Error searching YouTube: {e}")
            return None
    
    def play_trailer(self, e, movie_data):
        if not self.page:
            logger.error("No page reference available")
            return
        
        video_id = self.search_youtube_trailer(movie_data["title"])
        if not video_id:
            self._show_error_dialog(self.page, "Could not find trailer")
            return
    
        trailer_dialog = ft.AlertDialog(
            modal=True,
            content_padding=ft.padding.all(0,),
            #title=ft.Text(f"{movie_data['title']} - Trailer"),
            content=ft.Container(
                content=ft.Column([
                    ft.Row([
                        ft.IconButton(
                            icon=ft.icons.CLOSE,
                            on_click=lambda _: self.page.close(trailer_dialog)
                        )
                    ], alignment=ft.MainAxisAlignment.END),
                    ft.Container(
                        content=ft.WebView(
                            url=f"https://www.youtube.com/embed/{video_id}",
                            width=400,
                            height=225,
                        ),
                    )
                ]),
                width=400,
                height=300,
            ),
        )
        
        self.page.close(self.movie_info_dialog)
        self.page.open(trailer_dialog)
        self.page.update()

    def create_movie_card(self, movie_data):
        def handle_card_click(e):
            self._handle_download(e, movie_data["download_link"])

        def handle_info_click(e):
            self._show_movie_info_dialog(movie_data)

        def handle_single_tap(e):
            card = e.control.content

            # Animate to elevated state
            card.shadow = ft.BoxShadow(
                spread_radius=50 ,
                blur_radius=200,  # Large blur radius for that soft, dramatic effect
                color=ft.colors.BLUE_900,  # Dark blue color
                offset=ft.Offset(0, 0),  # Slight downward offset
                blur_style=ft.ShadowBlurStyle.NORMAL
            )


            card.scale = 1.1
            card.update()

        # Schedule reset after 500ms
        def reset_card(e):
            sleep(0.5)
            card = e.control.content
            card.shadow =ft.BoxShadow(
                spread_radius=-13,
                blur_radius=10,  # Large blur radius for that soft, dramatic effect
                color=ft.colors.BLUE_900,  # Dark blue color
                offset=ft.Offset(-8 , 6),   # Slight downward offset
                blur_style=ft.ShadowBlurStyle.NORMAL
            )
            card.scale = 1.0
            card.update()

        
        def _on_hover(e):
            page = e.page or self.page
            if page.platform == ft.PagePlatform.ANDROID:
                handle_single_tap(e)
                reset_card(e)
         
        try:

            image_url = movie_data["image_url"]
            proxied_url = f"{CONFIG['http(s)']}://{self.host}/api/image?url={quote(image_url)}" if image_url else None

            card_content = ft.GestureDetector(
                content=ft.Container(
                    content=ft.Column(
                        [
                            ft.Image(
                                src=proxied_url,
                                fit=ft.ImageFit.COVER,
                                height=CONFIG["default_image_height"],
                                width=CONFIG["default_image_width"],
                                error_content=self.create_fallback_content(),
                            ),
                            ft.ListTile(
                                leading=ft.Container(
                                    ft.Text("MOV", size=6, color=ft.colors.RED)
                                ),
                                title=ft.Text(
                                    movie_data["title"],
                                    size=9,
                                    weight=ft.FontWeight.BOLD,
                                    max_lines=2,
                                    overflow=ft.TextOverflow.ELLIPSIS,
                                ),
                                horizontal_spacing=1,
                                content_padding=ft.padding.symmetric(horizontal=1),
                            ),
                            ft.Row(
                                [
                                    ft.IconButton(
                                        icon=ft.icons.INFO,
                                        icon_size=16,
                                        tooltip="movie info",
                                        padding=ft.padding.only(bottom=5),
                                        on_click=handle_info_click
                                    ),
                                    ft.Container(
                                        ft.Text(
                                            movie_data["date"],
                                            size=8
                                        ),
                                        padding=ft.padding.only(right=5),
                                    ),
                                ],
                                alignment=ft.MainAxisAlignment.SPACE_AROUND,
                            ),
                        ],
                        spacing=0,
                        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                    ),
                    #animate_scale=self.animation_duration,  # Animation duration in milliseconds
                    #animate=self.animation_duration,  # Animation duration in milliseconds
                ),

                on_double_tap=handle_card_click,
            )

            return ft.GestureDetector(
                content=ft.Container(
                    content=ft.Card(
                        content=card_content,
                        elevation=0,
                        shadow_color=ft.colors.BLUE_ACCENT_100,
                    ),
                    shadow=ft.BoxShadow(
                        spread_radius=-13,
                        blur_radius=10,  # Large blur radius for that soft, dramatic effect
                        color=ft.colors.BLUE_900,  # Dark blue color
                        offset=ft.Offset(-8 , 6),   # Slight downward offset
                        blur_style=ft.ShadowBlurStyle.NORMAL
                    ),
                    animate_scale=self.animation_duration,  # Animation duration in milliseconds
                    animate=self.animation_duration,  # Animation duration in milliseconds
                ),
                col={"xs":6, "sm": 4, "md": 2},  # define the number of columns per screen size
                on_enter=handle_single_tap,
                on_exit=reset_card,
                on_hover=_on_hover,
            )    
        except Exception as e:
            logger.error(f"Error creating movie card: {e}")
            return None



class MovieGalleryApp:
    def __init__(self):
        self.card_creator = MovieCardCreator(CONFIG["proxy_port"], CONFIG["host"])
        self.all_movies = []
        self.filtered_movies = []
        self.current_index = 0
        self.search_index = 0
        self.is_loading = False
        self.is_updating = False  # New flag for update process
        self.responsive_row = None
        self.search_responsive_row = None
        self.load_more_button = None
        self.search_load_more_button = None
        self.page = None
        self.search_processor = SearchProcessor()
        self.search_bar = None
        self.suggestions_column = None
        self.main_content = None
        self.search_results_view = None
        self.route = "/"
        self.tabs = None
        self.is_typing = False
        self.scale = 0.7
        self.tab_scale = 0.99
        self.proxy_port = CONFIG["proxy_port"]
        self.host = CONFIG["host"]
        self.base_url = "https://nkiri.com/category/international"  # Add base URL for scraper
        self.sort_key = "date"  # Default sort
        self.sort_reverse = True  # Default order (newest first)
        self.sort_methods = {
            "date": lambda x: self.parse_date(x.get("date", "")),
            "title": lambda x: x.get("title", "").lower(),
            "rating": lambda x: self.parse_rating(x.get("rating", "0")),  # Updated to use parse_rating
        }
        self.sort_defaults = {
            "date": True,     # Newest first
            "title": False,   # A to Z
            "rating": True    # Highest first
        }
        
    def parse_rating(self, rating_str):
        """Parse rating string to float, handling 'No rating available' case"""
        try:
            # Handle cases where rating might contain stars or other characters
            if isinstance(rating_str, str):
                # If rating contains 'No' or is empty, return -1 to sort to end
                if 'No' in rating_str or not rating_str.strip():
                    return -1
                # Extract first number from string (handles "8.5 ⭐⭐⭐" format)
                number_match = re.search(r'(\d+\.?\d*)', rating_str)
                if number_match:
                    return float(number_match.group(1))
            return float(rating_str)  # Try direct conversion for numeric values
        except (ValueError, TypeError):
            return -1  # Return -1 for any parsing errors to sort to end
            
        
    def parse_date(self, date_str):
        """Parse date string into datetime object"""
        if not date_str:
            return datetime.min
            
        date_formats = [
            '%B %d, %Y',
            '%b %d, %Y',
            '%Y-%m-%d',
            '%d/%m/%Y',
            '%d-%m-%Y',
            '%d %B %Y',
            '%d %b %Y',
            '%Y/%m/%d',
        ]
        
        for date_format in date_formats:
            try:
                return datetime.strptime(date_str.strip(), date_format)
            except ValueError:
                continue
        return datetime.min
        
    def sort_movies(self, movies, key="date", reverse=None):
        """Sort movies based on specified criteria"""
        if key not in self.sort_methods:
            return movies
            
        if reverse is None:
            reverse = self.sort_defaults[key]
            
        return sorted(movies, key=self.sort_methods[key], reverse=reverse)

    def apply_sort(self, key=None, reverse=None):
        """Apply sorting to both main and filtered movies"""
        if key:
            self.sort_key = key
        if reverse is not None:
            self.sort_reverse = reverse
            
        try:
            # Sort all movies
            self.all_movies = self.sort_movies(self.all_movies, self.sort_key, self.sort_reverse)
            
            # Sort filtered movies if they exist
            if self.filtered_movies:
                self.filtered_movies = self.sort_movies(self.filtered_movies, self.sort_key, self.sort_reverse)
                
            # Reset indexes and clear existing content
            self.current_index = 0
            self.search_index = 0
            self.responsive_row.controls.clear()
            if self.search_responsive_row:
                self.search_responsive_row.controls.clear()
                
            # Reload content
            self.load_initial_batch()
            if self.tabs.selected_index == 1:  # If on search tab
                self.load_next_search_batch()
                
            self.page.update()
        except Exception as e:
            logger.error(f"Error during sort operation: {str(e)}")
            # Could add user feedback here
        
    def create_sort_button(self):
        """Create a sort button with dropdown menu"""
        def handle_sort_option(e):
            sort_key = e.control.data["key"]
            # Toggle reverse if same key, otherwise use default
            reverse = not self.sort_reverse if sort_key == self.sort_key else self.sort_defaults[sort_key]
            self.apply_sort(sort_key, reverse)
            
        return ft.PopupMenuButton(
            icon=ft.icons.SORT,
            tooltip="Sort movies",
            scale=self.scale,
            items=[
                ft.PopupMenuItem(
                    text="Date (Newest First)",
                    icon=ft.icons.CALENDAR_TODAY,
                    data={"key": "date"},
                    on_click=handle_sort_option
                ),
                ft.PopupMenuItem(
                    text="Title (A-Z)",
                    icon=ft.icons.SORT_BY_ALPHA,
                    data={"key": "title"},
                    on_click=handle_sort_option
                ),
                ft.PopupMenuItem(
                    text="Rating (Highest First)",
                    icon=ft.icons.STAR,
                    data={"key": "rating"},
                    on_click=handle_sort_option
                ),
            ],
        )

    def load_movies(self, file_path):
        try:
            with open(file_path, "r") as file:
                raw_data = json.load(file)
                self.all_movies = [MovieDataProcessor.process_movie_data(movie) for movie in raw_data]
                # Apply initial sort
                self.all_movies = self.sort_movies(self.all_movies, self.sort_key, self.sort_reverse)
                return True
        except Exception as e:
            logger.error(f"Error loading movies: {e}")
            return False

    def load_initial_batch(self):
        """Load initial batch of movies"""
        if self.is_loading or self.current_index >= len(self.all_movies):
            return

        self.is_loading = True

        end_index = min(self.current_index + CONFIG["batch_size"], len(self.all_movies))

        for movie in self.all_movies[self.current_index:end_index]:
            card = self.card_creator.create_movie_card(movie)
            if card:
                self.responsive_row.controls.append(card)

        self.current_index = end_index

        if self.load_more_button and self.current_index >= len(self.all_movies):
            self.load_more_button.visible = False

        self.is_loading = False

    def load_next_batch(self, e=None):
        """Load next batch of movies for main content"""
        if self.is_loading or self.current_index >= len(self.all_movies):
            return

        self.is_loading = True

        if self.load_more_button:
            self.load_more_button.text = "Loading..."
            self.load_more_button.disabled = True
            self.page.update()

        end_index = min(self.current_index + CONFIG["batch_size"], len(self.all_movies))

        for movie in self.all_movies[self.current_index:end_index]:
            card = self.card_creator.create_movie_card(movie)
            if card:
                self.responsive_row.controls.append(card)

        self.current_index = end_index

        if self.load_more_button:
            self.load_more_button.text = "Load More"
            self.load_more_button.disabled = False

            if self.current_index >= len(self.all_movies):
                self.load_more_button.visible = False

        self.page.update()
        self.is_loading = False
    
    def load_next_search_batch(self, e=None):
            """Load next batch of movies for search results"""
            if self.is_loading or self.search_index >= len(self.filtered_movies):
                return

            self.is_loading = True
            if self.search_load_more_button:
                self.search_load_more_button.text = "Loading..."
                self.search_load_more_button.disabled = True
                self.page.update()

            end_index = min(self.search_index + CONFIG["batch_size"], len(self.filtered_movies))

            for movie in self.filtered_movies[self.search_index:end_index]:
                card = self.card_creator.create_movie_card(movie)
                if card:
                    self.search_responsive_row.controls.append(card)
            
            self.search_index = end_index
            
            if self.search_load_more_button:
                self.search_load_more_button.text = "Load More"
                self.search_load_more_button.disabled = False
                if self.search_index >= len(self.filtered_movies):
                    self.search_load_more_button.visible = False
            
            self.page.update()
            self.is_loading = False


    def create_theme_toggle(self, page):
        def toggle_theme(e):
            page.theme_mode = (
                ft.ThemeMode.LIGHT
                if page.theme_mode == ft.ThemeMode.DARK
                else ft.ThemeMode.DARK
            )
            e.control.selected = not e.control.selected
            page.update()

        return ft.IconButton(
            icon=ft.Icons.WB_SUNNY_OUTLINED,
            tooltip="Toggle light/dark theme",
            selected_icon=ft.Icons.NIGHTS_STAY,
            on_click=toggle_theme,
            selected=True,
            scale=self.scale,
        )
    
    def activate_search_bar(self, e):
        self.search_bar.visible= not self.search_bar.visible # display the search bar
        if self.search_bar.visible == False:
            self.is_typing=False
        self.page.update() # Update the page to show the search bar is active
        
    async def perform_update(self):
        """Background task for updating movies"""
        try:
            scraper = MovieUpdateScraper(self.base_url, stop_on_no_update=True)
            new_movies = scraper.check_for_updates(max_pages=3)
            
            if self.update_progress.running:  # Check if update wasn't cancelled
                if new_movies:
                    self.update_progress.update_status(f"Found {len(new_movies)} new movies. Fetching movie information...")
                    await asyncio.sleep(0.1)  # Allow UI to update
                    
                    # Initialize movie processor
                    processor = MovieDataProcessor()
                    if not processor.validate_api_key():
                        raise Exception("Invalid TMDB API key")
                    
                    # Process movies in batches
                    processed_movies = []
                    start_idx = 0
                    batch_size = 10
                    
                    while start_idx < len(new_movies):
                        if not self.update_progress.running:
                            break
                            
                        self.update_progress.update_status(
                            f"Processing movies {start_idx + 1}-{min(start_idx + batch_size, len(new_movies))} of {len(new_movies)}..."
                        )
                        
                        result, start_idx = processor.process_batch(new_movies, start_idx, batch_size)
                        processed_movies = result
                        await asyncio.sleep(0.1)  # Allow UI to update
                    
                    if self.update_progress.running:  # Check if update wasn't cancelled
                        self.update_progress.update_status("Saving updated movies...")
                        # Update JSON file
                        scraper.update_json(processed_movies)
                        
                        # Reload movies
                        if self.load_movies("movies.json"):
                            # Reset indexes and clear existing content
                            self.current_index = 0
                            self.search_index = 0
                            self.responsive_row.controls.clear()
                            if self.search_responsive_row:
                                self.search_responsive_row.controls.clear()
                            
                            # Reload initial batch
                            self.load_initial_batch()
                            result_message = f"Successfully added {len(processed_movies)} new movies with information!"
                        else:
                            result_message = "Error reloading movies after update."
                    else:
                        result_message = "Update cancelled during processing."
                else:
                    result_message = "No new movies found."
                
                # Show result
                self.page.close(self.update_dialog)
                self.show_result_dialog(result_message)
                
        except Exception as e:
            logger.error(f"Error during update: {e}")
            if self.update_progress.running:  # Check if update wasn't cancelled
                self.page.close(self.update_dialog)
                self.show_result_dialog(f"Error updating movies: {str(e)}")
        
        finally:
            self.is_updating = False
            self.page.update()
            
    def update_movies(self, e):
        """Trigger movie update process"""
        if self.is_updating:
            return

        self.is_updating = True
        self.update_progress = UpdateProgress()
        
        # Set up cancel callback
        def on_cancel():
            self.is_updating = False
            self.page.close(self.update_dialog)
            self.show_result_dialog("Update cancelled")
            
        self.update_progress.on_stop = on_cancel

        # Create and show update dialog
        self.update_dialog = ft.AlertDialog(
            modal=True,
            title=ft.Text("Updating Movies"),
            content=self.update_progress,
        )
        
        self.page.open(self.update_dialog)
        
        # Start background task
        self.page.run_task(self.perform_update)        
            
    def show_result_dialog(self, message):
        """Show update result dialog"""
        result_dialog = ft.AlertDialog(
            modal=True,
            title=ft.Text("Update Complete"),
            content=ft.Text(message),
            actions=[
                ft.TextButton("OK", on_click=lambda _: self.page.close(result_dialog))
            ],
        )
        self.page.open(result_dialog)
        
    def setup_app_bar(self, page):
        theme_toggle_btn = self.create_theme_toggle(page)
        search_btn = ft.IconButton(
            icon=ft.icons.SEARCH,
            tooltip="Activate Search Bar",
            on_click=self.activate_search_bar,
            scale=self.scale,
        )
        
        refresh_btn = ft.IconButton(
            icon=ft.icons.REFRESH,
            tooltip="Check for new movies",
            on_click=self.update_movies,
            scale=self.scale,
        )
        
        sort_btn = self.create_sort_button()  # Add sort button
        
        def check_item_clicked(e):
            e.control.checked = not e.control.checked
            page.update()
        
        return ft.AppBar(
            leading=ft.Icon(ft.Icons.MOVIE, scale=self.scale,),
            leading_width=40,
            title=ft.Text("Movie Gallery", scale=self.scale,),
            center_title=False,
            actions=[ 
                search_btn,
                refresh_btn,
                theme_toggle_btn,
                sort_btn, 
            ],
        )
    
    def create_tips_card(self):
        tips_content = ft.AnimatedSwitcher(
            content=ft.Column([
                ft.Text(
                    f"• {tip}",
                    size=12,
                    color=ft.colors.BLUE_200,
                ) for tip in TIPS
            ]),
            transition=ft.AnimatedSwitcherTransition.SCALE,
            duration=500,
            switch_in_curve=ft.AnimationCurve.EASE_IN,
            switch_out_curve=ft.AnimationCurve.EASE_OUT,
        )
    
        tips_container = ft.Container(
            content=tips_content,
            visible=False,
            padding=ft.padding.only(left=16, right=16, bottom=16),
        )
    
        def toggle_tips(e):
            expand_button.selected = not expand_button.selected
            tips_container.visible = not tips_container.visible
            expand_button.icon = (
                ft.icons.EXPAND_LESS if tips_container.visible 
                else ft.icons.EXPAND_MORE
            )
            e.control.update()
            tips_container.update()
            
        expand_button = ft.IconButton(
            icon=ft.icons.EXPAND_MORE,
            selected_icon=ft.icons.EXPAND_LESS,
            selected=False,
            scale=self.scale,
            on_click=toggle_tips,
        )    
    
        return ft.Card(
            content=ft.Container(
                content=ft.Column([
                    ft.ListTile(
                        leading=ft.Icon(ft.icons.TIPS_AND_UPDATES),
                        title=ft.Text("Usage Tips", weight=ft.FontWeight.BOLD),
                        trailing=expand_button,
                        on_click=toggle_tips,
                    ),
                    tips_container
                ]),
                bgcolor=ft.colors.SURFACE_VARIANT,
                on_click=toggle_tips,
            ),
            elevation=4,
        )
    
    def create_welcome_section(self):
        return ft.Container(
            content=ft.Column([
                ft.Container(
                    content=ft.Text(
                        "Welcome to Movie Gallery! 🎬",
                        size=20,
                        weight=ft.FontWeight.BOLD,
                        color=ft.colors.BLUE_200,
                    ),
                    alignment=ft.alignment.center,
                    padding=ft.padding.only(bottom=10),
                ),
                self.create_tips_card(),
            ]),
            padding=ft.padding.only(bottom=10),
        )
        
    def create_responsive_row(self):
        self.responsive_row = ft.ResponsiveRow(
            expand=1,
            spacing=CONFIG["grid_spacing"],
            run_spacing=CONFIG["grid_spacing"],
            #padding=CONFIG["grid_padding"],
        )
        return self.responsive_row

    def create_load_more_button(self):
        self.load_more_button = ft.ElevatedButton(
            text="Load More",
            on_click=self.load_next_batch,
            style=ft.ButtonStyle(
                shape=ft.RoundedRectangleBorder(radius=10),
            ),
            height=40,
        )
        return self.load_more_button
    
    def create_search_load_more_button(self):
        self.search_load_more_button = ft.ElevatedButton(
            text="Load More",
            on_click=self.load_next_search_batch,
            style=ft.ButtonStyle(
                shape=ft.RoundedRectangleBorder(radius=10),
            ),
            height=40,
        )
        return self.search_load_more_button

    
    def create_search_bar(self):
        def handle_change(e):
            query = e.control.value
            if not query:
                self.is_typing = False
                e.control.close_view(query)
                e.control.update()
                return
                
            self.is_typing = True
            suggestions = self.search_processor.get_suggestions(query, self.all_movies)
            
            control=e.control
            control.controls = [
                ft.ListTile(
                    title=ft.Text(suggestion),
                    on_click=lambda e, s=suggestion: self.handle_suggestion_click(s),
                )
                for suggestion in suggestions
            ]
            if suggestions:
                control.open_view()
                control.update()
            else:
                control.close_view(query)
                control.update()
           
    
        def handle_submit(e):
            query = e.data
            if query:
                self.search_processor.add_recent_search(query)
                self.filtered_movies = [
                    movie for movie in self.all_movies 
                    if query.lower() in movie["title"].lower()
                ]
                self.search_index = 0 # Reset search index
                e.control.close_view(query)
                self.update_search_results()
                self.tabs.selected_index = 1
                self.is_typing=False
                self.page.update()
    
        self.search_bar = ft.SearchBar(
            view_elevation=4,
            divider_color=ft.colors.SURFACE_VARIANT,
            bar_hint_text="Search movies...",
            view_hint_text="Type to search movies...",
            on_change=handle_change,
            on_submit=handle_submit,
            bar_bgcolor=ft.colors.SURFACE_VARIANT,
            view_bgcolor=ft.colors.SURFACE,
            full_screen=False,
            visible=False,
            scale=self.scale,
        )

        return ft.Container(
            content=self.search_bar,
            padding=10,
        )
    
    def handle_suggestion_click(self, suggestion):
        self.search_bar.value = suggestion
        self.filtered_movies = [
            movie for movie in self.all_movies 
            if suggestion.lower() in movie["title"].lower()
        ]
        self.search_index = 0 # Reset search index
        self.search_bar.close_view(suggestion)
        self.update_search_results()
        self.tabs.selected_index = 1
        self.is_typing=False
        self.page.update()

    def show_main_content(self, e=None):
        self.tabs.selected_index = 0
        self.search_bar.value = ""
        self.is_typing = False
        self.page.update()

    def update_search_results(self):
        self.search_responsive_row = ft.ResponsiveRow(
                expand=True,
                spacing=CONFIG["grid_spacing"],
                run_spacing=CONFIG["grid_spacing"],
            )

        self.search_load_more_button = self.create_search_load_more_button()

        self.search_results_view.controls = [
            self.search_responsive_row,
            ft.Container(
                 content=self.search_load_more_button,
                 alignment=ft.alignment.center,
                 padding=ft.padding.only(top=20, bottom=20)
            ),
        ]

        self.search_results_view.scroll = ft.ScrollMode.AUTO
        
        self.load_next_search_batch()
        
        self.page.update()

    
    def initialize_ui(self, page: ft.Page):
        """Initialize all UI components"""
        self.page = page
        self.card_creator.set_page(page)
    
        page.theme_mode = ft.ThemeMode.DARK
        page.title = "Movie Gallery"
        appbar = self.setup_app_bar(page)
    
        if not self.load_movies("movies.json"):
            page.add(
                ft.Text(
                    "Error loading movies. Please check the data file.",
                    size=16,
                    weight=ft.FontWeight.BOLD,
                    color=ft.colors.RED,
                )
            )
            return False
    
        search_bar = self.create_search_bar()
        self.responsive_row = self.create_responsive_row()
        self.load_more_button = self.create_load_more_button()
        
    
        self.main_content = ft.Column(
            [
                self.create_welcome_section(),  # Add welcome section with tips
                self.responsive_row,
                ft.Container(
                    content=self.load_more_button,
                    alignment=ft.alignment.center,
                    padding=ft.padding.only(top=20, bottom=20),
                ),
            ],
            expand=True,
            scroll=ft.ScrollMode.AUTO
        )


        self.search_responsive_row = ft.ResponsiveRow(
                expand=True,
                spacing=CONFIG["grid_spacing"],
                run_spacing=CONFIG["grid_spacing"],
            )

        self.search_load_more_button = self.create_search_load_more_button()


        self.search_results_view = ft.Column(
           [
               ft.Container(
                    content=ft.Text("Search Results will be displayed here"),
                    alignment=ft.alignment.center,
                    expand=True,
                ),
           ],
            expand=True,
            scroll=ft.ScrollMode.AUTO,
            
        )
        ads_url=f"https://picsum.photos/{int(page.width)}/50" 
        print (ads_url)
        #proxied_url = f"http://{self.host}:{self.proxy_port}/proxy?url={quote(ads_url)}" if ads_url else None
        self.ads_banner=ft.ResponsiveRow(
            [
                ft.GestureDetector(
                    ft.Container(
                        bgcolor=ft.Colors.BLUE,
                        content=ft.Image(
                            src=ads_url,
                            fit=ft.ImageFit.COVER
                        ),
                        height=50,
                    ),
                on_tap=lambda e: page.launch_url("https://flet.dev/"),
                )
            ]
        )
        
        self.tabs = ft.Tabs(
            scale=self.tab_scale,
            expand=True,
            selected_index=0,
            on_change=lambda e: self.page.update(),
            tabs=[
                ft.Tab(
                    text="Home",
                    content=ft.SafeArea(
                        content=self.main_content,
                        expand=True,
                    ),
                ),
                ft.Tab(
                   text="Search",
                    content=ft.SafeArea(
                        content=self.search_results_view,
                        expand=True,
                    ), 
                )
            ]
        )

        
        main_wrapper=ft.Column(
            [
                search_bar,
                self.tabs,
                self.ads_banner,
                
            ],
            expand=True,
            #scroll=ft.ScrollMode.ALWAYS,
        )
        page.appbar=appbar
        page.add(
            main_wrapper
        )
        self.load_initial_batch()
        return True
        
    def main(self, page: ft.Page):
        """Main entry point for the application"""
        self.page = page
        if self.initialize_ui(page):
            page.update()
            print ("page loaded")

def main():
    app = MovieGalleryApp()
    ft.app(target=app.main,view=ft.AppView.WEB_BROWSER, use_color_emoji=True)

if __name__ == "__main__":
    main()
