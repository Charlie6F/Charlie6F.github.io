from flet_webview.webview import (
    WebView,
    WebviewConsoleMessageEvent,
    WebviewJavaScriptEvent,
    WebviewLogLevelSeverity,
    WebviewRequestMethod,
    WebviewScrollEvent,
)
