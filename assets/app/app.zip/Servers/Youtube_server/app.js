const cors = require('cors'); 
const express = require('express');
const { google } = require('googleapis');
const dotenv = require('dotenv');
const logging = require('debug')('app-server');

dotenv.config(); // Load environment variables from .env file

const app = express();
const port = 5000;
const HOSTNAME= '0.0.0.0'

const youtube = google.youtube('v3');
const API_KEY = process.env.YOUTUBE_API_KEY; // Get API key from environment variables

if (!API_KEY) {
    logging('Error: YouTube API key is not found in the environment variables (YOUTUBE_API_KEY).');
    process.exit(1);
}

app.use(cors({
    origin: [
        'https://bore.pub',
        'http://bore.pub',
        /\.bore\.pub$/,
        'http://bore.pub:8020',
        'http://bore.pub:7259',
        'https://nkiri.com', 
        'https://optimum-current-hawk.ngrok-free.app',
        'https://charlie6f.github.io',
        'http://localhost:8000',
        'http://localhost:8080',
        'http://bore.pub:7359',
        'http://bore.pub:8133',
        'https://ominous-space-fishstick-pjgvrxjqjwrjh9476-8080.app.github.dev/',
        'https://ominous-space-fishstick-pjgvrxjqjwrjh9476-9564.app.github.dev',
    ],
    methods: 'GET,HEAD,PUT,PATCH,POST,DELETE',
    credentials: true,
    optionsSuccessStatus: 204
}));


app.get('/', async (req, res) => {
    const searchQuery = req.query.q;

    if (!searchQuery) {
        return res.status(400).json({ error: 'Search query parameter "q" is missing.' });
    }

    try {
      
      const youtubeSearchOptions = {
          key: API_KEY,
          part: 'snippet',
          q: `${searchQuery} official trailer`, // Adjust this to optimize for trailer searches
          type: 'video',
          maxResults: 1, // Only get the most relevant result
          
      }
        const searchResponse = await youtube.search.list(youtubeSearchOptions);

        if (searchResponse.data.items && searchResponse.data.items.length > 0) {
            const videoId = searchResponse.data.items[0].id.videoId;
            res.json({ videoId });
        } else {
            res.status(404).json({ error: 'No trailer found for this search query.' });
        }
    } catch (error) {
        logging('Error during YouTube API request:', error);
        res.status(500).json({ error: 'An error occurred while processing your request.', details: error.message });
    }
});

// In app.js (YouTube API server)
app.use((req, res, next) => {
    logging(`YouTube API Server received request: ${req.method} ${req.url}`);
    next();
});


app.listen(5000, HOSTNAME => {
    logging(`Server running on port ${5000}`);
 });
