const http = require('http');
const https = require('https');
const url = require('url');
const { URL } = require('url');
const logging = require('debug')('proxy-server');
 
const PORT = 8010;
const HOSTNAME = '0.0.0.0';

// Define allowed origins explicitly
const ALLOWED_ORIGINS = [
    'http://bore.pub:7259',
    'http://bore.pub:8020',
    'https://nkiri.com',
    'https://optimum-current-hawk.ngrok-free.app',
    'https://charlie6f.github.io',
    'http://localhost:8000',
    'http://localhost:8551',
    'http://bore.pub:7359',
    'http://bore.pub:8133',
    'https://ominous-space-fishstick-pjgvrxjqjwrjh9476-8080.app.github.dev',
    'https://ominous-space-fishstick-pjgvrxjqjwrjh9476-9564.app.github.dev'
];

function isValidOrigin(origin) {
    // If no origin is present in the request, reject it
    if (!origin) return false;
    
    // Check if the origin is in our allowed list
    return ALLOWED_ORIGINS.includes(origin);
}

function setCORSHeaders(res, origin) {
    if (!isValidOrigin(origin)) {
        // If origin is not valid, don't set CORS headers
        // This will cause the browser to block the request
        return false;
    }
    
    // Set the specific origin instead of '*'
    res.setHeader('Access-Control-Allow-Origin', origin);
    
    // Only set needed methods and headers
    res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, ngrok-skip-browser-warning');
    res.setHeader('Access-Control-Expose-Headers', 'ngrok-skip-browser-warning');
    
    // Optional: Set max age to cache preflight requests
    res.setHeader('Access-Control-Max-Age', '86400'); // 24 hours
    
    return true;
}

const server = http.createServer((req, res) => {
    const origin = req.headers.origin;
    const parsedUrl = url.parse(req.url, true);
    logging(`Received request from origin: ${origin}`);

    // Handle preflight requests
    if (req.method === 'OPTIONS') {
        if (setCORSHeaders(res, origin)) {
            res.writeHead(204);
            res.end();
        } else {
            res.writeHead(403);
            res.end('Forbidden');
        }
        return;
    }

    if (parsedUrl.pathname === '/' && parsedUrl.query.url) {
        // Validate origin before processing request
        if (!isValidOrigin(origin)) {
            res.writeHead(403);
            res.end('Forbidden');
            return;
        }

        const targetUrl = parsedUrl.query.url;
        logging(`Proxying request for: ${targetUrl}`);

        try {
            const targetURLObj = new URL(targetUrl);
            
            // Optional: Whitelist target domains
            // const allowedTargetDomains = ['nkiri.com', 'picsum.photos'];
            // if (!allowedTargetDomains.includes(targetURLObj.hostname)) {
            //     throw new Error('Target domain not allowed');
            // }

            const protocol = targetURLObj.protocol === 'https:' ? https : http;

            const proxyOptions = {
                headers: {
                    'User-Agent': 'Mozilla/5.0 (compatible; ProxyServer/1.0)',
                    // Don't forward origin header to target
                    'X-Forwarded-For': req.socket.remoteAddress
                }
            };

            const proxyRequest = protocol.get(targetUrl, proxyOptions, (proxyResponse) => {
                setCORSHeaders(res, origin);
                
                res.writeHead(proxyResponse.statusCode, {
                    'Content-Type': proxyResponse.headers['content-type'] || 'application/octet-stream',
                });
                proxyResponse.pipe(res);
            }).on('error', (err) => {
                logging(`Error fetching ${targetUrl}: ${err}`);
                setCORSHeaders(res, origin);
                res.writeHead(500);
                res.end(JSON.stringify({ error: 'Proxy request failed' }));
            });

        } catch(e) {
            logging(`Error with url: ${targetUrl}, error ${e}`);
            setCORSHeaders(res, origin);
            res.writeHead(400);
            res.end(JSON.stringify({ error: 'Invalid request' }));
        }
    } else {
        res.writeHead(404);
        res.end('Not Found');
    }
});

server.listen(PORT, HOSTNAME, () => {
    logging(`Proxy server listening on http://${HOSTNAME}:${PORT}`);
});
