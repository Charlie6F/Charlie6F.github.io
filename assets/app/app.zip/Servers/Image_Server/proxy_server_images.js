const http = require('http');
const https = require('https');
const url = require('url');
const { URL } = require('url');
const logging = require('debug')('proxy-server');

const PORT = 8010;
const HOSTNAME = '0.0.0.0';

// Define allowed origins as an array
const ALLOWED_ORIGINS = [
    'http://bore.pub:7259',
    'http://bore.pub:8020',
    'https://nkiri.com',
    'https://optimum-current-hawk.ngrok-free.app',
    'https://charlie6f.github.io',
    'http://localhost:8000',
    'http://localhost:8551'
];

function setCORSHeaders(res, origin) {
    // Check if the origin is in the allowed list
    logging (origin)
    const allowedOrigin = ALLOWED_ORIGINS.includes(origin) ? origin : ALLOWED_ORIGINS[0];
    
    res.setHeader('Access-Control-Allow-Origin', allowedOrigin);
    res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, ngrok-skip-browser-warning');
    res.setHeader('Access-Control-Expose-Headers', 'ngrok-skip-browser-warning');
    res.setHeader('ngrok-skip-browser-warning', 'true');
}

const server = http.createServer((req, res) => {
    const origin = req.headers.origin;
    const parsedUrl = url.parse(req.url, true);
    logging(`Received request: ${req.method} ${req.url}`);

    // Handle preflight requests
    if (req.method === 'OPTIONS') {
        setCORSHeaders(res, origin);
        res.writeHead(204);
        res.end();
        return;
    }

    if (parsedUrl.pathname === '/' && parsedUrl.query.url) {
        const targetUrl = parsedUrl.query.url;
        logging(`Proxying request for: ${targetUrl}`);

        try {
            const targetURLObj = new URL(targetUrl);
            const protocol = targetURLObj.protocol === 'https:' ? https : http;

            const proxyOptions = {
                headers: {
                    'ngrok-skip-browser-warning': 'true',
                    'User-Agent': 'Mozilla/5.0 (compatible; ProxyServer/1.0)'
                }
            };

            const proxyRequest = protocol.get(targetUrl, proxyOptions, (proxyResponse) => {
                logging(`proxyResponse statusCode ${proxyResponse.statusCode} headers are: ${JSON.stringify(proxyResponse.headers)}`);

                // Set CORS headers
                setCORSHeaders(res, origin);

                res.writeHead(proxyResponse.statusCode, {
                    'Content-Type': proxyResponse.headers['content-type'] || 'application/octet-stream',
                });
                proxyResponse.pipe(res);
            }).on('error', (err) => {
                logging(`Error fetching ${targetUrl}: ${err}`);
                setCORSHeaders(res, origin);
                res.writeHead(500, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ error: `Error fetching ${targetUrl}`, details: err.message }));
            });

            proxyRequest.on('error', (err) => {
                logging(`Error on client request: ${err}`);
                setCORSHeaders(res, origin);
                res.writeHead(500, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ error: `Error on client request: ${err}`, details: err.message }));
            });

        } catch(e) {
            logging(`Error with url: ${targetUrl}, error ${e}`);
            setCORSHeaders(res, origin);
            res.writeHead(500, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ error: `Error with url: ${targetUrl}`, details: e.message }));
        }
    } else {
        setCORSHeaders(res, origin);
        res.writeHead(404, { 'Content-Type': 'text/plain' });
        res.end('Not Found');
        logging(`Not found: ${req.url}`);
    }
});

server.on('error', (err) => {
    logging(`Server error: ${err}`);
});

server.listen(PORT, HOSTNAME, () => {
    logging(`Proxy server listening on http://${HOSTNAME}:${PORT}`);
});