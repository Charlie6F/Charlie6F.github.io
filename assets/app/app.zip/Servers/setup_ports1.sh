CODESPACE_NAME=$(gh codespace list --json name -q '.[0].name')
gh codespace ports forward -c $CODESPACE_NAME 9564:9564 & 
gh codespace ports forward -c $CODESPACE_NAME 8080:8080 & 
gh codespace ports visibility -c $CODESPACE_NAME 9564:public &
gh codespace ports visibility -c $CODESPACE_NAME 8080:public
