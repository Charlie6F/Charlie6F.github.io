#!/bin/bash

# Define the correct Node.js path for Termux
export NODE_PATH="/home/codespace/nvm/current/bin/node"
export GH_PATH="/usr/bin/gh"

# Function to check if node is available
check_node() {
    if [ ! -x "$NODE_PATH" ]; then
        echo "Node.js is not found at $NODE_PATH"
        echo "Please ensure Node.js is properly installed"
        exit 1
    fi
}

# Function to check if a port is in use
check_port() {
    nc -z localhost $1 > /dev/null 2>&1
    return $?
}

# Function to start servers
start_servers() {
    echo 'Starting servers'
    python -m http.server --directory /workspaces/Mov/packs 9564 &
    PYTHON_PID=$!
    
    DEBUG=orchestrator,proxy-server,app-server,download-server $NODE_PATH main.js &
    NODE_PID=$!

    if [ $? -ne 0 ]; then
        echo "Failed to start servers"
        kill $PYTHON_PID 2>/dev/null
        exit 1
    fi

    echo "Python server started with PID: $PYTHON_PID"
    echo "Node server started with PID: $NODE_PID"
}

# Function to forward ports using GitHub Codespaces
forward_ports() {
    local port1=$1
    local port2=$2

    echo "Forwarding ports $port1 and $port2"

    # Check if GitHub CLI is available
    if [ ! -x "$GH_PATH" ]; then
        echo "gh is not found at $GH_PATH"
        echo "Please ensure gh is properly installed"
        exit 1
    fi

    # Get current codespace name
    CODESPACE_NAME=$(gh codespace list --json name -q '.[0].name')
    if [ -z "$CODESPACE_NAME" ]; then
        echo "Failed to get codespace name"
        exit 1
    fi

    # Forward ports using the specific codespace
    gh codespace ports forward -c "$CODESPACE_NAME" $port1:$port1 &
    if [ $? -ne 0 ]; then
        echo "Failed to forward port $port1"
        exit 1
    fi

    gh codespace ports forward -c "$CODESPACE_NAME" $port2:$port2 &
    if [ $? -ne 0 ]; then
        echo "Failed to forward port $port2"
        exit 1
    fi

    # Make ports public
    gh codespace ports visibility -c "$CODESPACE_NAME" $port1:public
    gh codespace ports visibility -c "$CODESPACE_NAME" $port2:public

    echo "Ports $port1 and $port2 are now forwarded and public"
}

# Function to monitor server processes
monitor_process() {
    while true; do
        # Check if both processes are running
        if ! kill -0 $PYTHON_PID 2>/dev/null || ! kill -0 $NODE_PID 2>/dev/null; then
            echo "One or more server processes died, restarting..."
            kill $PYTHON_PID 2>/dev/null
            kill $NODE_PID 2>/dev/null
            start_servers
            forward_ports 9564 8080
        fi

        sleep 10  # Check every 10 seconds
    done
}

# Cleanup function
cleanup() {
    echo "Shutting down..."
    kill $PYTHON_PID 2>/dev/null
    kill $NODE_PID 2>/dev/null
    exit 0
}

# Set up trap for cleanup on script termination
trap cleanup EXIT SIGINT SIGTERM

# Check if Node.js is available
check_node

# Initial startup
start_servers
forward_ports 9564 8080

# Start monitoring
monitor_process
