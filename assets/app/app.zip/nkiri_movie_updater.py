import requests
from bs4 import BeautifulSoup
import json
import time
from urllib.parse import urljoin
from datetime import datetime
import os

class MovieUpdateScraper:
    def __init__(self, base_url, json_file='movies.json', stop_on_no_update=True):
        self.base_url = base_url
        self.json_file = json_file
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        }
        self.months = ['JANUARY', 'FEBRUARY', 'MARCH', 'APRIL', 'MAY', 'JUNE', 
                      'JULY', 'AUGUST', 'SEPTEMBER', 'OCTOBER', 'NOVEMBER', 'DECEMBER']
        self.existing_movies = self.load_existing_movies()
        self.stop_on_no_update = stop_on_no_update
        
    def load_existing_movies(self):
        """Load existing movies from JSON file if it exists"""
        if os.path.exists(self.json_file):
            try:
                with open(self.json_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except json.JSONDecodeError:
                print(f"Error reading {self.json_file}. Starting fresh.")
                return []
        return []

    def movie_exists(self, new_movie):
        """Check if a movie already exists in our database"""
        return any(
            existing['title'] == new_movie['title'] and 
            existing['link'] == new_movie['link']
            for existing in self.existing_movies
        )

    def get_page_content(self, url):
        try:
            response = requests.get(url, headers=self.headers)
            response.raise_for_status()
            return response.text
        except requests.RequestException as e:
            print(f"Error fetching page: {e}")
            return None

    def check_for_updates(self, max_pages=5):
        """Check recent pages for new movies"""
        new_movies = []
        page = 1
        
        while page <= max_pages:
            current_url = f"{self.base_url}/page/{page}/" if page > 1 else self.base_url
            print(f"Checking page {page} for updates: {current_url}")
            
            content = self.get_page_content(current_url)
            if not content:
                break
                
            soup = BeautifulSoup(content, 'html.parser')
            page_movies = self.extract_movies_from_page(soup)
            
            if not page_movies:
                break
            
            # Check for new movies
            found_existing = False
            new_movies_on_page = False
            for movie in page_movies:
                if self.movie_exists(movie):
                    found_existing = True
                    continue
                new_movies.append(movie)
                new_movies_on_page = True
            
            # If we found an existing movie and no new movies on this page,
            # we can stop checking further pages
            if self.stop_on_no_update and found_existing and not new_movies_on_page:
                print(f"No new movies found after page {page}")
                break
                
            page += 1
            time.sleep(1)  # Polite delay between requests
            
        return new_movies

    def extract_date(self, article):
        """Enhanced date extraction with multiple fallback methods"""
        date = None
        
        # Method 1: Try blog-entry-date class
        date_elem = article.find(class_='blog-entry-date')
        if date_elem:
            date = date_elem.text.strip()
            return date
            
        # Method 2: Try header with meta-date or time
        header_elem = article.find(class_='blog-entry-header')
        if header_elem:
            date_elem = header_elem.find(class_='meta-date') or header_elem.find('time')
            if date_elem:
                date = date_elem.text.strip()
                return date
                
        # Method 3: Try entry-date class
        date_elem = article.find(class_='entry-date')
        if date_elem:
            date = date_elem.text.strip()
            return date
            
        # Method 4: Look for any element with date-related classes
        date_candidates = article.find_all(class_=lambda x: x and ('date' in x.lower() or 'meta' in x.lower()))
        for candidate in date_candidates:
            if candidate.text and any(month in candidate.text.upper() for month in self.months):
                date = candidate.text.strip()
                return date
                
        # Method 5: Look for time element
        time_elem = article.find('time')
        if time_elem:
            date = time_elem.text.strip()
            return date
            
        # Method 6: Look for elements with datetime attribute
        datetime_elem = article.find(attrs={'datetime': True})
        if datetime_elem:
            date = datetime_elem.get('datetime', '').split('T')[0]
            return date
            
        return date

    def extract_movies_from_page(self, soup):
        movies = []
        articles = soup.find_all('article', class_='post')
        
        for article in articles:
            title_element = article.find('h2', class_='entry-title')
            if not title_element:
                continue
                
            link_element = title_element.find('a')
            if not link_element:
                continue
                
            title = link_element.get_text().strip()
            link = link_element['href']
            
            # Extract image
            image_element = article.find('img')
            image_link = image_element['src'] if image_element else None
            
            # Extract date using enhanced method
            date = self.extract_date(article)
            
            # Get download link
            download_info = self.extract_download_link(link)
            download_link = download_info.get('download_link') if download_info else None
            direct_url = download_info.get('direct_url') if download_info else None
            
            movie_data = {
                "title": title,
                "link": link,
                "image_link": image_link,
                "date": date,
                "download_link": download_link
            }
            if direct_url:
                movie_data['direct_url'] = direct_url
            movies.append(movie_data)
            
        return movies

    def extract_download_link(self, movie_url):
        content = self.get_page_content(movie_url)
        if not content:
            return None
            
        soup = BeautifulSoup(content, 'html.parser')
        
        download_info = {}
        #First we check if the url has the direct link
        direct_link_element = soup.find('a', class_='elementor-button elementor-button-link elementor-size-md', href=True)
        if direct_link_element:
            download_info['direct_url'] = direct_link_element['href']
            print ('1',download_info)
            if download_info:
                return download_info
        
        
        download_section = soup.find('div', class_='download-links') or soup.find('div', class_='entry-content') or soup.find('a', class_='elementor-button elementor-button-link elementor-size-md', href=True)
        if not download_section:
            print ('2',download_info)
            return download_info
            
        for link in download_section.find_all('a', href=True):
            if 'downloadwella.com' in link['href']:
                download_info['download_link'] = link['href']
                print ('3',download_info)
                return download_info
                
        print ('4',download_info)        
        return download_info

    def update_json(self, new_movies):
        """Update the JSON file with new movies"""
        if new_movies:
            self.existing_movies.extend(new_movies)
            with open(self.json_file, 'w', encoding='utf-8') as f:
                json.dump(self.existing_movies, f, indent=2, ensure_ascii=False)
            print(f"Added {len(new_movies)} new movies to {self.json_file}")
        else:
            print("No new movies found")

def main():
    base_url = "https://nkiri.com/category/international"  # Replace with actual base URL
    
    continue_scan=1
    
    if not continue_scan:
        #Example with stop_on_no_update = True
        scraper_stop = MovieUpdateScraper(base_url, stop_on_no_update = True)
        print ("Running with stop_on_no_update = True")
        new_movies_stop = scraper_stop.check_for_updates(max_pages=3)
        scraper_stop.update_json(new_movies_stop)
        print ("\n")
    
    if continue_scan:      
        #Example with stop_on_no_update = False
        scraper_continue = MovieUpdateScraper(base_url, stop_on_no_update = False)
        print ("Running with stop_on_no_update = False")
        new_movies_continue = scraper_continue.check_for_updates(max_pages=93)
        scraper_continue.update_json(new_movies_continue)
        print("Update check completed!")

if __name__ == "__main__":
    main()
